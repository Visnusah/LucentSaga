-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 09, 2024 at 10:09 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gautam-liquor-store`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` int(11) NOT NULL,
  `added_on` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `product_id`, `quantity`, `price`, `added_on`) VALUES
(14, 8, 9, 1, 7200, '2024-05-09 23:45:40');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(3, 'Wine'),
(4, 'Whisky'),
(6, 'Beer'),
(7, 'Vodka');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `total`, `address`, `payment_method`, `status`, `created_at`) VALUES
(6, 8, 17000.00, 'Laudantium officia ', 'cod', 'pending', '2024-05-07 11:35:52'),
(7, 8, 7200.00, 'Ut deserunt dolorem ', 'cod', 'pending', '2024-05-07 12:11:44'),
(8, 8, 7200.00, 'jkadsjfajkdsghf', 'cod', 'pending', '2024-05-07 12:48:20'),
(9, 8, 24200.00, 'Balaju, Kathmandu', 'cod', 'pending', '2024-05-09 06:14:19');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`item_id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(11, 6, 8, 2, 8500.00),
(12, 7, 9, 1, 7200.00),
(13, 8, 9, 1, 7200.00),
(14, 9, 8, 2, 8500.00),
(15, 9, 9, 1, 7200.00);

-- --------------------------------------------------------

--
-- Table structure for table `payments`



-- Table structure for table `payment_info`
--

CREATE TABLE `payment_info` (
  `id` int(11) NOT NULL,
  `item_number` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `amount` double(10,2) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `txn_id` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `sku` varchar(50) NOT NULL,
  `product_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `quantity`, `category_id`, `sku`, `product_image`) VALUES
(8, 'Buffalo Trace Kentucky Bourbon Whiskey 750ML', 'Buffalo Trace Kentucky Straight Bourbon Whiskey is distilled, aged and bottled at the most award-winning distillery in the world.\r\n\r\nMade from the finest corn, rye and barley malt, this whiskey ages in new oak barrels for years in century old warehouses until the peak of maturity.\r\n\r\nThe taste is rich and complex, with hints of vanilla, toffee and candied fruit. The smooth finish lingers on the palate. This will never change.', 8500.00, 5, 4, 'WKB750', 'img_663a1055be5fe2.96830152.png'),
(9, 'Kentucky Tavern Bourbon Whiskey 1L', 'First produced in the early 1900s, the legendary Kentucky Tavern Bourbon brand was created by whiskey pioneer James Thompson who founded the famous Glenmore Distillery in Owensboro, KY.\r\n\r\nCOLOUR: Burnished copper.\r\n\r\nNOSE: Caramel, raisin, grain husk, and reedy wood aromas.\r\n\r\nPALATE: Somewhat muted, dryish medium body with black pepper, sweet buttercream, and spice accents.\r\n\r\nFINISH: Finishes with a creamy vanilla and white ash fade.', 7200.00, 5, 4, 'WKK1000', 'img_663a10f0beb886.21490995.png'),
(10, ' Two Oceans Chardonnay 750ML', 'Colour: Light straw with golden specs.\r\n\r\nNose:Fruit dominated aromas of subtle citrus, apricot and lime with delicate oak nuances in the background.\r\n\r\nPalate: This medium-bodied, lightly-oaked wine has abundant fruit flavours complemented by a fantastic acid/sugar balance to keep it lingering in the mouth.\r\n\r\nRecommendations: Enjoy with fish, roast chicken and light salads.', 2170.00, 10, 3, 'WNT750', 'img_663a1138c0bb32.76501111.png'),
(11, 'Ruslan Premium 750ML + 1 Soan Papdi 200G Free', '~~ Ruslan Vodka Special Offer ~~\r\nGet 1 Soan Papdi 200G FREE with each bottle!\r\n~~~~~~\r\n\r\nThe most popular vodka in Nepal for over 25 years. Traditional ingredients based on an old Russian recipe State of the art filtration technology and triple distillation ensuring a crisp, consistent taste.\r\n\r\nA true 100% pure Vodka with no after effects.', 2155.00, 5, 7, 'VDK1', 'img_663d208620ba22.21021982.png'),
(12, 'SKYY Vodka 750ML (Bottled in Nepal) + 1 Fanny Bag Free', '~~ SKYY Vodka Special Offer ~~\r\nGet 1 Fanny Bag FREE with each bottle!\r\n~~~~~~\r\n\r\nBorn in San Francisco in 1992, SKKY Vodka is made with grain based imported spirits.\r\n\r\nInspired by the pure, clean essence of the San Francisco coast, SKYY delivers a lighter, fresher-tasting vodka & soda with character.', 2400.00, 3, 7, 'VK2', 'img_663d20d62fb3d0.88029466.png'),
(13, 'Tuborg 330ML x 5 Bottles + 1 Glass Free', '~~ Tuborg Beer Special Offer ~~\r\nBuy 5 Bottles and Get 1 Exclusive Glass FREE!\r\n~~~~~~\r\n\r\nLaunched in Nepal in 1990 and enjoyed worldwide since 1880, Tuborg is the largest selling, most preferred and therefore the number 1 beer brand in Nepal.\r\n\r\nTuborg recently unveiled its new look with the innovative Pull-Off Cap for the first time in Nepal.', 1125.00, 10, 6, 'BRT1', 'img_663d211f6c6bf2.15554300.png'),
(14, 'VAT 69 750ML', 'VAT 69 is a blended Whisky produced by William Sanderson. It has upfront malty, heather sweetness and a lovely peat smoke savoury finish.', 4750.00, 4, 4, 'WK69', 'img_663d2181f04474.62370265.png'),
(15, 'Arna 6.4 Special Edition Bottle 330ML', 'This Special Edition Beer is dedicated to the Nepal Cricket Fans and is brewed using Malt, Rice, Hops, Water and lots of Nepalese Passions and Emotions.', 170.00, 20, 6, 'BR2', 'img_663d22013fdca5.23272796.png'),
(16, 'Barahsinghe Craft Yaktoberfest Marzen Style Bottle 650ML', 'Barahsinghe Yaktoberfest is a malty German amber lager that has been part of the Oktoberfest celebration.\r\n\r\nBrewed with imported Munich, Vienna and Pilsner malts, natural spring water and noble hops, this Marzen style beer balanced with spicy hop aromatics will certainly keep your Oktoberfest spirit alive.', 400.00, 10, 6, 'BR400', 'img_663d2232d86c47.40783566.png'),
(17, '8848 Vodka 180ML', 'Mount Everest, known as Chhomolungma by Sherpas meaning “Mother Goddess of the Earth” is the highest point in the world standing at 8848 meters. This vodka is crafted from imported grain spirits, distilled from Soft French Winter Wheat, and blended in small batches with Pure Spring Water from the Himalayas.', 535.00, 10, 7, 'VK8848', 'img_663d228a0936b0.58874599.png'),
(18, 'Manang Valley Premium Sweet White 750ML', 'Embark on a journey of discovery and wonder with our exquisite wines, crafted from a tantalizing blend of homegrown apples handpicked from our own orchard, 3000 meters above sea level.\r\n\r\nNurtured by the pure and icy-cold glacial streams of the Marshyangdi River, our wine promises a refreshingly unique & artistic experience that will captivate your senses and ignite your spirit.\r\n\r\nSavor the essence of the Annapurna mountains with every sip, as the crisp and clean flavors capture the untamed wilderness of Manang. Join us on a thrilling adventure through the natural wonders of the Himalayas and indulge in the spirit of our handcrafted mountain wine.', 1025.00, 5, 3, 'WN765', 'img_663d238b3c9eb5.22863953.png'),
(19, 'Big Master Sweet Red 4L Box', 'Wine Style: Original fruits (grape) natural flavour with sweet red wine finish.\r\n\r\nRecommendations: Enjoy with baked pasta, roasted meat or your favourite dishes.\r\n\r\nServing Temperature: 14-18 °C', 3955.00, 5, 3, 'WNBM1', 'img_663d23cc8b2506.44469388.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','client') NOT NULL,
  `phone` bigint(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `phone`, `address`, `age`) VALUES
(1, 'admin', 'admin@admin.com', 'admin', 'admin', 0, '', 0),
(2, 'Kimberly York', 'xunibikef@mailinator.com', '$2y$10$ZwlyPy4f/AorC1uV5v/wWOYIMt9TOIyo1IO1v.qWLI0WD0jDNdx6G', 'admin', 39, 'Laudantium officia ', 0),
(3, 'Barrett Day', 'tyvufykok@mailinator.com', '$2y$10$zqe5d90V/ulBqvbpvXvtYezwMb4z/AdGd4ZW.HAbXVo97tcnREV0G', 'admin', 216, 'Hic labore eveniet ', 0),
(4, 'Chaim Mendoza', 'bywa@mailinator.com', '$2y$10$bOj0SUcrQmKaEYJdnD31KObabFrYry7ZsGgf3cCY8zds/uJTXRjvi', 'admin', 324, 'Tempor illo non est ', 0),
(5, 'Mohan Basnet', 'basnet.mohan2030@gmail.com', '$2y$10$p5KyTRPnRh2n5PKGlzPI9OnP8VaRY7B8THcascU.p2019xjbKwnYu', 'admin', 560, 'Anix', 0),
(6, 'Client1', 'client@admin.com', '$2y$10$i0HEiPbGVw1JbPxm4iBGJ.78c1Pc0Yy.ATMvJNiOz8nvcTaLfIKdq', 'admin', 234234, 'Chabahil', 0),
(7, 'Kiara Cook', 'zywewibucy@mailinator.com', '$2y$10$H6F7vypUUgfp546ZFS918OHkqp869ghVLXZMkA50IUP2T5e.lU2xe', 'admin', 53, 'Temporibus veritatis', 25),
(8, 'Vasme Don', 'vasme@client.com', '$2y$10$E25.jGgJG4PgISNaKx8QEOaVgNRWE5GSdO8/E.qekVPNtVWCxzZdW', 'admin', 981111111, 'Chabahil', 30);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `payment_info`
--
ALTER TABLE `payment_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `payment_info`
--
ALTER TABLE `payment_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
