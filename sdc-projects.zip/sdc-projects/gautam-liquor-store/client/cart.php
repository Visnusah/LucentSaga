<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .btn-group {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
<?php $total = 0; ?>
<br><br><br>
<?php include './components/navbar.php' ?>
<div class="container mt-5">
    <h2>Your Shopping Cart</h2>
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Product Name</th>
                <th scope="col">Quantity</th>
                <th scope="col">Price</th>
                <th scope="col">Total</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            include '../db.php';

            $user_id = $_SESSION['user_id'];

            $sql = "SELECT p.name, p.price, c.quantity, c.product_id FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $index = 1;
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $index++ . "</td>";
                    echo "<td>" . $row["name"] . "</td>";
                    echo "<td>" . $row["quantity"] . "</td>";
                    echo "<td>Rs." . $row["price"] . "</td>";
                    echo "<td>Rs." . number_format($row["price"] * $row["quantity"], 2) . "</td>";
                    echo "<td><button class='btn btn-danger' onclick='removeFromCart(" . $row["product_id"] . ")'>Remove</button></td>";
                    echo "</tr>";
                    $total += $row['quantity'] * $row['price'];
                }
            } else {
                echo "<tr><td colspan='6' class='text-center'>Your cart is empty!</td></tr>";
            }
            $conn->close();
            ?>
            <tr>
                <td colspan="4">Total</td>
                <td>Rs.<?php echo number_format($total, 2); ?></td>
            </tr>
        </tbody>
    </table>
    <hr>
    <h3>Checkout</h3>
    <form action="checkout.php" method="post">
        <div class="form-group">
            <label for="address">Shipping Address:</label>
            <input type="text" class="form-control" id="address" name="address" required>
        </div>
        <input type="hidden" name="payment_method" value="esewa">
        <div class="btn-group">
            <button type="submit" class="btn btn-primary">Pay with Esewa</button>
    </form>
    <form method='post' action='<?php echo PAYPAL_URL; ?>'>
        <input type='hidden' name='business' value='<?php echo PAYPAL_EMAIL; ?>'>
        <input type='hidden' name='item_number' value='YOUR_CART_ID'>
        <input type='hidden' name='item_name' value=<?php echo $data['name'] ?>>
        <input type='hidden' name='amount' value='<?php echo number_format($total / 130, 2); ?>'>
        <input type='hidden' name='currency_code' value='<?php echo CURRENCY; ?>'>
        <input type='hidden' name='no_shipping' value='1'>
        <input type='hidden' name='return' value='<?php echo RETURN_URL; ?>'>
        <input type='hidden' name='cancel_return' value='<?php echo CANCEL_URL; ?>'>
        <input type='hidden' name='notify_url' value='<?php echo NOTIFY_URL; ?>'>
        <input type="hidden" name="cmd" value="_xclick">
        <button type='submit' class='btn btn-primary'>Pay with Paypal</button>
    </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function removeFromCart(productId) {
        $.post('remove-from-cart.php', { product_id: productId }, function(response) {
            location.reload();
        });
    }
</script>

</body>
</html>
