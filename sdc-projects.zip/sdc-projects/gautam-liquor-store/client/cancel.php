<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <?php include './components/navbar.php' ?>
        <!-- Banner Section -->
        <div class="jumbotron jumbotron-fluid mt-4">
            <div class="container text-center">
                <h1 class="display-4">Sorry!</h1>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <main role="main" class="col-md-9 col-lg-10 px-4 m-5">
                    <div class="content mt-5 text-center">
                        <h1>Your payment has been cancelled.</h1>
</div>
</main>
</div>
</div>
    </div>
</body>
</html>