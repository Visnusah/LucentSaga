<?php
    require_once  '../db.php';

    // Check if a category is selected
    if (isset($_GET['category'])) {
        $category_id = $_GET['category'];

        // Fetch category name for display
        $sql_category = "SELECT name FROM categories WHERE id = ?";
        $stmt_category = $conn->prepare($sql_category);
        $stmt_category->bind_param("i", $category_id);
        $stmt_category->execute();
        $result_category = $stmt_category->get_result();
        $category = $result_category->fetch_assoc()['name'];

        // Fetch products for the selected category
        $sql_products = "SELECT * FROM products WHERE category_id = ?";
        $stmt_products = $conn->prepare($sql_products);
        $stmt_products->bind_param("i", $category_id);
        $stmt_products->execute();
        $result_products = $stmt_products->get_result();
    } else {
        // If no category is selected, display all products
        $sql_products = "SELECT * FROM products";
        $result_products = $conn->query($sql_products);
    }
?>

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gautam Liquor Store</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    </head>
    <body>
        <?php include 'components/navbar.php'; ?>

        <!-- Banner Section -->
        <div class="jumbotron jumbotron-fluid mt-4">
            <div class="container text-center">
                <h1 class="display-4"><?php echo isset($category) ? $category . " Products" : "All Products"; ?></h1>
            </div>
        </div>
        <!-- Featured Products Section -->
        <div class="container mt-5">
        
        <div class="row">
        <?php while ($row = $result_products->fetch_assoc()): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo "../admin/uploads/".$row['product_image']; ?>" class="card-img-top" alt="<?php echo $row['name']; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['name']; ?></h5>
                        <p class="card-text">Price: Rs.<?php echo $row['price']; ?></p>
                        <a href="single-product.php?id=<?php echo $row["id"]; ?>" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>           
    
        </div>

        <!-- Footer Section -->
        <footer class="bg-dark text-white text-center py-3">
            <p>&copy; 2024 Gautam Liquor Store. All rights reserved.</p>
        </footer>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    </body>
</html>
