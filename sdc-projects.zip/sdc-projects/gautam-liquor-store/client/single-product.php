<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gautam Liquor Store</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .product-image {
            max-height: 400px;
            object-fit: cover;
        }
        .product-details {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .btn-primary {
            background-color: #0069d9;
            border-color: #0062cc;
        }
    </style>
</head>
<body>
    <?php include 'components/navbar.php'; ?>

    <div class="container mt-5">
        <div class="row">
            <?php
            include '../db.php';
            if(isset($_GET['id'])){
                $product_id = $_GET['id'];
                $sql = "SELECT * FROM products WHERE id = $product_id";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
            ?>
            <div class="col-md-6 my-5">
                <img src="<?php echo '../admin/uploads/'.$row['product_image']; ?>" class="img-fluid product-image" alt="<?php echo $row['product_image']; ?>">
            </div>
            <div class="col-md-6 my-5">
                <div class="product-details">
                    <h2><?php echo $row['name']; ?></h2>
                    <p>Description: <?php echo $row['description']; ?></p>
                    <p>Price: Rs.<?php echo $row['price']; ?></p>
                    <form id="add-to-cart-form" action="add-to-cart.php" method="post">
                        <div class="form-group">
                            <label for="quantity">Quantity:</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" value="1" min="1" required>
                        </div>
                        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                        <input type="hidden" name="price" value="<?php echo $row['price']; ?>">
                        <button type="submit" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
            <?php
                } else {
                    echo "<div class='col-12'><div class='alert alert-danger' role='alert'>Product not found!</div></div>";
                }
                $conn->close();
            }
            ?>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cartModalLabel">Item Added to Cart</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    The item has been added to your cart.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="continue-shopping-btn">Continue Shopping</button>
                    <a href="cart.php" class="btn btn-primary">Go to Cart</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#add-to-cart-form').on('submit', function(event) {
                event.preventDefault();
                $.ajax({
                    url: 'add-to-cart.php',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(response) {
                        $('#cartModal').modal('show');
                    }
                });
            });

            $('#continue-shopping-btn').on('click', function() {
                window.location.href = 'index.php'; // redirect to the home page!!
            });
        });
    </script>
</body>
</html>
