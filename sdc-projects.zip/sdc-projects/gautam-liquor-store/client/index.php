<?php
    include '../db.php';

    function getMostOrderedProducts($conn, $limit = 6) {
        $sql = "SELECT p.*, SUM(od.quantity) AS total_quantity
                FROM products p
                LEFT JOIN order_items od ON p.id = od.product_id
                GROUP BY p.id
                ORDER BY total_quantity DESC
                LIMIT ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        return $result;
    }
    
    // Fetch most ordered products (featured products)
    $featured_products = getMostOrderedProducts($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gautam Liquor Store</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        .jumbotron {
            /* background: url('https://source.unsplash.com/1600x600/?liquor') no-repeat center center; */
            background-size: cover;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
        }
        .jumbotron .container {
            background-color: rgba(0, 0, 0, 0.5);
            padding: 2rem;
            border-radius: 10px;
        }
        .card {
            transition: transform 0.2s ease;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card img {
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }
        .card-title {
            font-weight: bold;
            font-size: 1.2rem;
        }
        footer {
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <?php include 'components/navbar.php'; ?>

    <!-- Banner Section -->
    <div class="jumbotron jumbotron-fluid mt-4">
        <div class="container text-center">
            <h1 class="display-4">Welcome to Our Liquor Store</h1>
            <p class="lead">Find a wide selection of premium liquors for every occasion.</p>
        </div>
    </div>

    <!-- Featured Products Section -->
    <div class="container mt-5 text-center">
        <h3 class="display-4 mb-4">Featured Products</h3>
        <div class="row">
            <?php while ($row = $featured_products->fetch_assoc()): ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <img src="<?php echo "../admin/uploads/".$row['product_image']; ?>" class="card-img-top" alt="<?php echo $row['name']; ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $row['name']; ?></h5>
                            <p class="card-text">Price: Rs.<?php echo $row['price']; ?></p>
                            <a href="single-product.php?id=<?php echo $row["id"]; ?>" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- Footer Section -->
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2024 Gautam Liquor Store. All rights reserved.</p>
    </footer>

    <!-- Bootstrap JS and any additional scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
