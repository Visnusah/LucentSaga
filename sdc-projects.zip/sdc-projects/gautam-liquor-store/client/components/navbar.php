<?php
    session_start();
    include '../db.php';
    $sql_categories = "SELECT * FROM categories";
    $result_categories = $conn->query($sql_categories);
?>

<nav class="navbar navbar-expand-lg navbar-light fixed-top mb-4">
    <a class="navbar-brand" href="index.php">
       <img src="<?php echo "../images/logo.png"; ?>" alt="Logo">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Products
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <?php while ($row = $result_categories->fetch_assoc()): ?>
                        <a class="dropdown-item" href="products.php?category=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a>
                    <?php endwhile; ?>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="about.php">About Us</a>
            </li>
            <?php if (isset($_SESSION["user_id"])) { ?>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Welcome, <?php echo $_SESSION["username"]; ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            <?php } else { ?>
                <li class="nav-item">
                    <a class="nav-link" href="register.php">Register</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="cart.php">
                <i class="fa-solid fa-cart-shopping"></i>
                </a>
            </li>
        </ul>
    </div>
</nav>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://kit.fontawesome.com/ac88dd6f87.js" crossorigin="anonymous"></script>
<script>
    
    // Open dropdown on hover
    $('.nav-item.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
    }, function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });
</script>
<style>
    .nav-link i {
        font-size: 1.2rem;
        color: #000;
    }
    .nav-item:hover .nav-link {
        color: #0056b3;
    }
    .dropdown-item:hover {
        background-color: #f8f9fa;
    }
    .nav-link:hover i {
        color: #0056b3;
    }
</style>
