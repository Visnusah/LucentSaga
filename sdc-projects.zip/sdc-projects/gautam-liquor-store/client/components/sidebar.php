<nav class="col-md-2 d-none d-md-block bg-dark sidebar">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="#">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_product.php">Add Product</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_products.php">View Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_category.php">Add Category</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_categories.php">View Categories</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_orders.php">View Orders</a>
            </li>
        </ul>
    </div>
</nav>