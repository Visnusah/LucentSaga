<?php
session_start();

if (isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit();
}

include "../db.php";

if (isset($_POST["register"])) {
    $fullName = $_POST["fullName"];
    $phoneNo = $_POST["phoneNo"];
    $address = $_POST["address"];
    $age = $_POST["age"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    
    if($age > 18){
        $check_sql = "SELECT * FROM users WHERE email='$email'";
        $check_result = $conn->query($check_sql);
        if ($check_result->num_rows > 0) {
            echo "<div class='container mt-5 alert alert-danger'>Email already exists!</div>";
        } else {
            $insert_sql = "INSERT INTO users (username, email, password, phone, address, age) VALUES ('$fullName','$email', '$password', '$phoneNo', '$address', '$age')";
            if ($conn->query($insert_sql) === TRUE) {
                echo "<div class='container col-md-5 mt-5 alert alert-success'>User registered successfully</div>";
                header("location:login.php");
                exit();
            } else {
                echo "Error: " . $insert_sql . "<br>" . $conn->error;
            }
        }
    } else {
        echo "<div class='container mt-5 alert alert-danger'>You must be greater than 18 years old!</div>";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Gautam Liquor Store</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script>
        function validateForm() {
            var fullName = document.getElementById('fullName').value.trim();
            var age = document.getElementById('age').value;
            var phoneNo = document.getElementById('phoneNo').value.trim();
            var address = document.getElementById('address').value.trim();
            var email = document.getElementById('email').value.trim();
            var password = document.getElementById('password').value.trim();

            // Validate full name
            if (fullName === '') {
                alert('Full Name is required.');
                return false;
            }

            // Validate age
            if (age === '' || age < 1 || age > 120) {
                alert('Please enter a valid age between 1 and 120.');
                return false;
            }

            // Validate phone number
            var phonePattern = /^\d{10}$/;
            if (phoneNo === '' || !phonePattern.test(phoneNo)) {
                alert('Please enter a valid 10-digit phone number.');
                return false;
            }

            // Validate address
            if (address === '') {
                alert('Address is required.');
                return false;
            }

            // Validate email
            var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (email === '' || !emailPattern.test(email)) {
                alert('Please enter a valid email address.');
                return false;
            }

            // Validate password
            if (password === '' || password.length < 6) {
                alert('Password must be at least 6 characters long.');
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
<div class="d-lg-flex half">
    <div class="bg order-1 order-md-2" style="background-image: url('../images/barrel.jpg');"></div>
    <div class="contents order-2 order-md-1">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7">
            <h3>Register to <strong>Gautam Liquor Store</strong></h3>
            <p class="mb-4">#1 Online Liquor Store in Nepal.</p>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" onsubmit="return validateForm();">
                <div class="form-group">
                    <label for="fullName">Full Name:</label>
                    <input type="text" class="form-control" id="fullName" name="fullName" required>
                </div>
                <div class="form-group">
                    <label for="age">Age:</label>
                    <input type="number" class="form-control" id="age" name="age" required min="1" max="120">
                </div>
                <div class="form-group">
                    <label for="phoneNo">Phone Number:</label>
                    <input type="number" class="form-control" id="phoneNo" name="phoneNo" required pattern="\d{10}" maxlength="10">
                </div>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <input type="text" class="form-control" id="address" name="address" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" id="password" name="password" required minlength="6">
                </div>
                <button type="submit" name="register" class="btn custom-btn">Register</button>
            </form>
            <a href="login.php">Already have account!</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>