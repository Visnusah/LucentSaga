<?php
include ('../db.php');

define("IPN_LOG_FILE", "ipn.log");
$raw_post_data = file_get_contents('php://input');
$raw_post_array = explode('&', $raw_post_data);
$myPost = array();
foreach ($raw_post_array as $keyval) {
    $keyval = explode('=', $keyval);
    if (count($keyval) == 2) {
        $myPost[$keyval[0]] = urldecode($keyval[1]);
    }
}

$req = 'cmd=_notify-validate';
foreach ($myPost as $key => $value) {
    $value = urlencode($value);
    $req .= "&$key=$value";
}

$ch = curl_init(PAYPAL_URL);
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));

$res = curl_exec($ch);
if (curl_errno($ch) != 0) {
    curl_close($ch);
    exit;
} else {
    curl_close($ch);
}

$tokens = explode("\r\n\r\n", trim($res));
$res = trim(end($tokens));

if (strcmp($res, "VERIFIED") == 0) {
    $item_number = $_POST['item_number']; // This represents user_id
    $payment_status = $_POST['payment_status'];
    $amount = $_POST['mc_gross'];
    $currency = $_POST['mc_currency'];
    $txn_id = $_POST['txn_id'];
    $receiver_email = $_POST['receiver_email'];

    if (strtolower($receiver_email) != strtolower(PAYPAL_EMAIL)) {
        error_log(date('[Y-m-d H:i e] ') . "Invalid Business Email: $req" . PHP_EOL, 3, IPN_LOG_FILE);
        exit();
    }

    if (strtolower($currency) != strtolower(CURRENCY)) {
        error_log(date('[Y-m-d H:i e] ') . "Invalid Currency: $req" . PHP_EOL, 3, IPN_LOG_FILE);
        exit();
    }

    // Check if transaction ID is unique
    $db = new DB;
    $db->query("SELECT * FROM `payment_info` WHERE txn_id=:txn_id");
    $db->bind(':txn_id', $txn_id);
    $db->execute();
    $unique_txn_id = $db->rowCount();

    if (!empty($unique_txn_id)) {
        error_log(date('[Y-m-d H:i e] ') . "Invalid Transaction ID: $req" . PHP_EOL, 3, IPN_LOG_FILE);
        $db->close();
        exit();
    } else {
        $db->query("INSERT INTO `payment_info` (`item_number`, `payment_status`, `amount`, `currency`, `txn_id`) VALUES (:item_number, :payment_status, :amount, :currency, :txn_id)");
        $db->bind(":item_number", $item_number);
        $db->bind(":payment_status", $payment_status);
        $db->bind(":amount", $amount);
        $db->bind(":currency", $currency);
        $db->bind(":txn_id", $txn_id);
        $db->execute();
    }

    // Update order status
    $updateOrderStatus = $conn->prepare("UPDATE orders SET status = 'completed' WHERE user_id = ?");
    $updateOrderStatus->bind_param("i", $item_number);
    $updateOrderStatus->execute();

    // Reduce stock and clear cart
    $user_id = $item_number; // In this case, item_number represents user_id

    // Fetch the cart items for the user
    $sql_get_cart_items = "SELECT product_id, quantity FROM cart WHERE user_id = ?";
    $stmt = $conn->prepare($sql_get_cart_items);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $product_id = $row['product_id'];
        $quantity = $row['quantity'];

        // Decrement the product quantity in the stock
        $sql_update_product = "UPDATE products SET stock = stock - ? WHERE id = ?";
        $stmt_update_product = $conn->prepare($sql_update_product);
        $stmt_update_product->bind_param("ii", $quantity, $product_id);
        $stmt_update_product->execute();
    }

    // Clear the user's cart after successful payment
    $sql_clear_cart = "DELETE FROM cart WHERE user_id = ?";
    $stmt_clear_cart = $conn->prepare($sql_clear_cart);
    $stmt_clear_cart->bind_param("i", $user_id);
    $stmt_clear_cart->execute();

    $db->close();
} else if (strcmp($res, "INVALID") == 0) {
    error_log(date('[Y-m-d H:i e] ') . "Invalid IPN: $req" . PHP_EOL, 3, IPN_LOG_FILE);
}

function getUserIDFromCartID($cart_id) {
    return intval($cart_id);
}
?>
