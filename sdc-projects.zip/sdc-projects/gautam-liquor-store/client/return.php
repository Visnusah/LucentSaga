<?php
session_start();
include('db.php');

function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Check if the GET parameters are set
if (!empty($_GET)) {
    // Sanitize and set session variables from the GET parameters
    $_SESSION['product'] = sanitize_input($_GET['item_name']);
    $_SESSION['txn_id'] = sanitize_input($_GET['tx']);
    $_SESSION['amount'] = sanitize_input($_GET['amt']);
    $_SESSION['status'] = sanitize_input($_GET['st']);
}

// Process the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment'])) {
    try {
        // Connect to the database
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Insert data into the new table (e.g., confirmed_payments)
        $sql = "INSERT INTO confirmed_payments (payment_id, item_name, amount, status, created_at)
                VALUES (:payment_id, :item_name, :amount, :status, :created_at)";

        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':payment_id' => $_POST['txn_id'],
            ':item_name' => $_POST['product'],
            ':amount' => $_POST['amount'],
            ':status' => $_POST['status'],
            ':created_at' => date('Y-m-d H:i:s')
        ]);

        echo "Payment details have been confirmed and stored.";

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null;
}

try {
    // Retrieve payment details from the database
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT payment_id, item_name, amount, status FROM payments WHERE payment_id = :payment_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':payment_id' => $_SESSION['txn_id']]);
    $paymentDetails = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include './components/navbar.php'; ?>
    <div class="jumbotron jumbotron-fluid mt-4">
        <div class="container text-center">
            <h1 class="display-4">Thank You!</h1>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <main role="main" class="col-md-9 col-lg-10 px-4 m-5">
                <div class="content mt-5 text-center">
                    <div class="alert alert-primary" role="alert">
                        <h1>Your payment has been received successfully.</h1>
                    </div>
                </div>
                <form method="post" action="return.php">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td>Transaction Id</td>
                                <td><?php echo $_SESSION['txn_id']; ?></td>
                            </tr>
                            <tr>
                                <td>Description</td>
                                <td><?php echo $_SESSION['product']; ?></td>
                            </tr>
                            <tr>
                                <td>Amount</td>
                                <td><?php echo $_SESSION['amount']; ?></td>
                            </tr>
                            <tr>
                                <td>Payment Status</td>
                                <td><?php echo $_SESSION['status']; ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <input type="hidden" name="txn_id" value="<?php echo $_SESSION['txn_id']; ?>">
                    <input type="hidden" name="product" value="<?php echo $_SESSION['product']; ?>">
                    <input type="hidden" name="amount" value="<?php echo $_SESSION['amount']; ?>">
                    <input type="hidden" name="status" value="<?php echo $_SESSION['status']; ?>">
                    <button type="submit" name="confirm_payment" class="btn btn-primary">Confirm Payment</button>
                </form>
            </main>
        </div>
    </div>
</body>
</html>
