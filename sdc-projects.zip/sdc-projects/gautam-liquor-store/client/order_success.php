<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Successful</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include './components/navbar.php' ?>
        <!-- Banner Section -->
        <div class="jumbotron jumbotron-fluid">
            <div class="container text-center">
                <br>
                <br>
                <h1 class="display-4">Thank You!</h1>
                <h1>Your order has been successfully placed!</h1>
    <p>Thank you for shopping with us.</p>
            </div>
        </div>

    
</body>
</html>
