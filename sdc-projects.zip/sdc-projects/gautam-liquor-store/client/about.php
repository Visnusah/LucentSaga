<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <?php include './components/navbar.php' ?>
        <!-- Banner Section -->
        <div class="jumbotron jumbotron-fluid mt-4">
            <div class="container text-center">
                <h1 class="display-4">About Us</h1>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <main role="main" class="col-md-9 col-lg-10 px-4 m-5">
                    <div class="content mt-5">
                    <h2>About Us</h2>
        <p>Welcome to our liquor store! We are dedicated to providing a wide selection of high-quality liquors to our customers. Whether you're looking for a fine wine, craft beer, or premium spirits, we've got you covered.</p>
        <p>Our team is passionate about curating the best products for your enjoyment. We strive to offer exceptional customer service and a seamless shopping experience.</p>
        <p>Thank you for choosing our store for all your liquor needs. Cheers!</p>
        <h3>Our Team</h3>
        <ul>
            <li>Kushal Banjara - Founder & CEO</li>

        </ul>
        <div class="content mt-5">
                    <h2>Contact Us</h2>
        <p>Have a question or need assistance? Feel free to reach out to us using the contact details below:</p>
        <ul>
            <li>Email: info@liquorstore.com</li>
            <li>Phone: 9800000000</li>
            <li>Address: Kathmandu, Nepal</li>
        </ul>
</div>

</div>
</div>
</main>
</div>
</body>
</html>
