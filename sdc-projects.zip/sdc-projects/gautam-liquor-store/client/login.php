<?php
    session_start();

    if (isset($_SESSION["user_id"])) {
        header("Location: index.php");
        exit();
    }

    include "../db.php";

    if (isset($_POST["login"])) {
        $email = $_POST["email"];
        $password = $_POST["password"];

        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = $conn->query($sql);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row["password"])) {
                $_SESSION["user_id"] = $row["id"];
                $_SESSION["user_email"] = $row["email"];
                $_SESSION["username"] = $row["username"];
                header("Location: index.php");
                exit();
            } else {
                echo "<div class='container col-md-5 mt-5 alert alert-danger'>Invalid email or password!</div>";
            }
        } else {
            echo "<div class='container col-md-5 mt-5 alert alert-danger'>User not found!</div>";
        }
    }
    $conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Gautam Liquor Store</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="d-lg-flex half">
    <div class="bg order-1 order-md-2" style="background-image: url('../images/barrel.jpg');"></div>
    <div class="contents order-2 order-md-1">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7">
            <h3>Login to <strong>Gautam Liquor Store</strong></h3>
            <p class="mb-4">#1 Online Liquor Store in Nepal.</p>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
              <div class="form-group first">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control" placeholder="your-email@gmail.com" id="email">
              </div>
              <div class="form-group last mb-3">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Your Password" id="password">
              </div>

              <input type="submit" name="login" value="Log In" class="btn btn-block custom-btn">

            </form>
          </div>
        </div>
      </div>
    </div>

    
  </div>
    
</body>
</html>
