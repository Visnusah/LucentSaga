<?php
    session_start();
    include '../db.php';

    $user_id = $_SESSION['user_id'] ?? 0;
    $address = $_POST['address'] ?? '';
    $payment_method = $_POST['payment_method'] ?? '';

    $totalQuery = "SELECT SUM(price * quantity) AS total FROM cart WHERE user_id = ?";
    $totalStmt = $conn->prepare($totalQuery);
    $totalStmt->bind_param("i", $user_id);
    $totalStmt->execute();
    $totalResult = $totalStmt->get_result();
    if ($totalRow = $totalResult->fetch_assoc()) {
        $total = $totalRow['total'];
    } else {
        $total = 0;
    }

    $orderQuery = "INSERT INTO orders (user_id, total, address, payment_method, status) VALUES (?, ?, ?, ?, 'pending')";
    $orderStmt = $conn->prepare($orderQuery);
    $orderStmt->bind_param("idss", $user_id, $total, $address, $payment_method);
    $orderStmt->execute();
    $order_id = $conn->insert_id;

    $cartQuery = "SELECT product_id, quantity, price FROM cart WHERE user_id = ?";
    $cartStmt = $conn->prepare($cartQuery);
    $cartStmt->bind_param("i", $user_id);
    $cartStmt->execute();
    $cartItems = $cartStmt->get_result();

    while ($item = $cartItems->fetch_assoc()) {
        $itemQuery = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        $itemStmt = $conn->prepare($itemQuery);
        $itemStmt->bind_param("iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']);
        $itemStmt->execute();
    }

    $clearCartQuery = "DELETE FROM cart WHERE user_id = ?";
    $clearCartStmt = $conn->prepare($clearCartQuery);
    $clearCartStmt->bind_param("i", $user_id);
    $clearCartStmt->execute();

    header('Location: order_success.php');
    exit;
?>


