<!-- <?php
    session_start();

    if (!isset($_SESSION["user_id"])) {
        header("Location: login.php");
    }

    include '../db.php';

    if (isset($_POST["product_id"]) && isset($_POST["quantity"])) {
        $product_id = $_POST["product_id"];
        $user_id = $_SESSION["user_id"];
        $quantity = $_POST["quantity"];
        $price = $_POST["price"];

        $sql = "INSERT INTO cart (user_id, product_id, quantity, price) VALUES ('$user_id', '$product_id', '$quantity', '$price')";
        if ($conn->query($sql) === TRUE) {
            echo "<div class='container mt-5 alert alert-success'>Product added to cart successfully.</div>";
        } else {
            echo "<div class='container mt-5 alert alert-success'>Error adding product to cart: " . $conn->error."</div>";
        }
    }
    header("location:cart.php");
    $conn->close();
?> -->


