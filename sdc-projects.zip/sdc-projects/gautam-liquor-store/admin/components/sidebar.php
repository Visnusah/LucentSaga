<!-- <nav class="col-md-2 d-none d-md-block bg-dark sidebar">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="admin_dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_product.php">Add Product</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_products.php">View Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_category.php">Add Category</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_categories.php">View Categories</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_orders.php">View Orders</a>
            </li>
        </ul>
    </div>
</nav>



<style>
    .sidebar {
        background-color: #343a40;
        height: 100vh;
        position: fixed;
        padding-top: 20px;
    }
    .sidebar-sticky {
        position: relative;
        top: 5px;
        height: calc(100vh - 48px);
        overflow-x: hidden;
        overflow-y: auto;
    }
    .nav-item {
        margin: 10px 0;
    }
    .nav-link {
        color: #ffffff;
        font-weight: 500;
        padding: 10px 15px;
        text-align: left;
        transition: background-color 0.2s, color 0.2s;
    }
    .nav-link:hover {
        background-color: #495057;
        color: #ffffff;
        text-decoration: none;
    }
    .nav-link.active {
        /* background-color: #007bff; */
        color: #ffffff;
    }
</style> -->

<?php
    $current_page = basename($_SERVER['PHP_SELF']);
?>

<nav class="col-md-2 d-none d-md-block bg-dark sidebar">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'admin_dashboard.php') ? 'active' : ''; ?>" href="admin_dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'add_product.php') ? 'active' : ''; ?>" href="add_product.php">Add Product</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'view_products.php') ? 'active' : ''; ?>" href="view_products.php">View Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'add_category.php') ? 'active' : ''; ?>" href="add_category.php">Add Category</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'view_categories.php') ? 'active' : ''; ?>" href="view_categories.php">View Categories</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'view_orders.php') ? 'active' : ''; ?>" href="view_orders.php">View Orders</a>
            </li>
        </ul>
    </div>
</nav>

<style>
    .sidebar {
        background-color: #343a40;
        height: 100vh;
        position: fixed;
        padding-top: 20px;
    }
    .sidebar-sticky {
        position: relative;
        top: 0;
        height: calc(100vh - 48px);
        overflow-x: hidden;
        overflow-y: auto;
    }
    .nav-item {
        margin: 10px 0;
    }
    .nav-link {
        color: #ffffff;
        font-weight: 500;
        padding: 10px 15px;
        text-align: left;
        transition: background-color 0.2s, color 0.2s;
    }
    .nav-link:hover {
        background-color: #495057;
        color: #ffffff;
        text-decoration: none;
    }
    .nav-link.active {
        background-color: #007bff;
        color: #ffffff;
    }
</style>
