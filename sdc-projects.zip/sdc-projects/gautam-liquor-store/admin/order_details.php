<?php
session_start();
require_once '../db.php';

$order_id = $_GET['order_id'] ?? 0;

$query = "
    SELECT o.order_id, o.total, o.address, o.payment_method, o.status, o.created_at, u.username, u.email
    FROM orders o
    JOIN users u ON o.user_id = u.id
    WHERE o.order_id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

$itemQuery = "
    SELECT oi.product_id, p.name, oi.quantity, oi.price
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
";
$itemStmt = $conn->prepare($itemQuery);
$itemStmt->bind_param("i", $order_id);
$itemStmt->execute();
$itemResult = $itemStmt->get_result();
?>
  <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="admin-style.css">
    </head>
    <body>
        <?php include './components/navbar.php' ?>
        <div class="container-fluid" style="margin-top: 4rem;">
            <div class="row">
                <?php include './components/sidebar.php' ?>
                <main role="main" class="col-md-9 col-lg-10 px-4">
                    <div class="content mt-5">
    <h1>Order Details for Order #<?php echo htmlspecialchars($order_id); ?></h1>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Order Information</h5>
            <p><strong>User:</strong> <?php echo htmlspecialchars($order['username']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
            <p><strong>Total:</strong> Rs.<?php echo number_format($order['total'], 2); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($order['address']); ?></p>
            <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($order['payment_method']); ?></p>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
            <p><strong>Created At:</strong> <?php echo htmlspecialchars($order['created_at']); ?></p>
        </div>
    </div>
    <br>
    <h5>Order Items</h5>
    <table class="table">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = $itemResult->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($item['name']); ?></td>
                <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                <td>Rs.<?php echo number_format($item['price'], 2); ?></td>
                <td>Rs.<?php echo number_format($item['quantity'] * $item['price'], 2); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
            </div>
            </main>
            </div>
</body>
</html>
