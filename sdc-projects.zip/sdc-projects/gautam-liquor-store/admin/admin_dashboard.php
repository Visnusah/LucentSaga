<?php
session_start();
include '../db.php';  // Include your database connection setup here

// Check if user is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

// Query to fetch data
$sql_users = "SELECT COUNT(*) AS user_count FROM users";
$sql_products = "SELECT COUNT(*) AS product_count FROM products";
$sql_orders = "SELECT COUNT(*) AS order_count FROM orders";
$sql_sales = "SELECT month, sales FROM saleschart";
$sql_transactions = "
    SELECT month(date) as month, 
           SUM(CASE WHEN transaction_type = 'buy' THEN quantity ELSE 0 END) AS total_buys,
           SUM(CASE WHEN transaction_type = 'sell' THEN quantity ELSE 0 END) AS total_sells
    FROM product_transactions
    GROUP BY month(date)
";

$result_users = $conn->query($sql_users);
$result_products = $conn->query($sql_products);
$result_orders = $conn->query($sql_orders);
$result_sales = $conn->query($sql_sales);
$result_transactions = $conn->query($sql_transactions);

// Fetch counts
$user_count = ($result_users->num_rows > 0) ? $result_users->fetch_assoc()['user_count'] : 0;
$product_count = ($result_products->num_rows > 0) ? $result_products->fetch_assoc()['product_count'] : 0;
$order_count = ($result_orders->num_rows > 0) ? $result_orders->fetch_assoc()['order_count'] : 0;

// Fetch sales data
$months = [];
$sales = [];

if($result_sales->num_rows > 0) {
    while($row = $result_sales->fetch_assoc()) {
        $months[] = $row['month'];
        $sales[] = $row['sales'];
    }
}

// Fetch transaction data
$transaction_months = [];
$total_buys = [];
$total_sells = [];

if($result_transactions->num_rows > 0) {
    while($row = $result_transactions->fetch_assoc()) {
        $transaction_months[] = $row['month'];
        $total_buys[] = $row['total_buys'];
        $total_sells[] = $row['total_sells'];
    }
}

// Close connections
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="admin-style.css">

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);
      google.charts.setOnLoadCallback(drawTransactionChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Metrics', 'Count'],
          ['Total Users', <?php echo $user_count; ?>],
          ['Total Products', <?php echo $product_count; ?>],
          ['Total Orders', <?php echo $order_count; ?>]
        ]);

        var options = {
          chart: {
            title: 'Overview Report',
            subtitle: 'Total User, Total Product, and Total Order',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }

      function drawTransactionChart() {
        var data = google.visualization.arrayToDataTable([
          ['Month', 'Total Buys', 'Total Sells'],
          <?php
          for ($i = 0; $i < count($transaction_months); $i++) {
              echo "['" . $transaction_months[$i] . "', " . $total_buys[$i] . ", " . $total_sells[$i] . "],";
          }
          ?>
        ]);

        var options = {
          chart: {
            title: 'Product Transactions',
            subtitle: 'Total Buys and Total Sells by Month',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('transactionchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
</head>
<body>
    <?php include './components/navbar.php'; ?>
    <div class="container-fluid" style="margin-top: 3.5rem;">
        <div class="row">
            <?php include './components/sidebar.php'; ?>
            <main role="main" class="col-md-9 col-lg-10 px-4">
                <div class="content mt-5">
                    <h2>Dashboard</h2>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Total Users</h5>
                                    <p class="card-text"><?php echo $user_count; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Total Products</h5>
                                    <p class="card-text"><?php echo $product_count; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Total Orders</h5>
                                    <p class="card-text"><?php echo $order_count; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-5">
                        <h2>Sales Report</h2>
                        <div id="columnchart_material" style="width: 800px; height: 500px;"></div>
                    </div>
                    <div class="mt-5">
                        <h2>Product Transactions</h2>
                        <div id="transactionchart_material" style="width: 800px; height: 500px;"></div>
                    </div>
                    <div class="mt-5">
                        <h2>Add New Transaction</h2>
                        <a href="add_transaction.php" class="btn btn-primary">Add Transaction</a>
                    </div>
                    <br><br><br>
                </div>
            </main>
        </div>
    </div>
</body>
</html>
