<?php
session_start();
include '../db.php';  // Include your database connection setup here

// Check if user is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $transaction_type = $_POST['transaction_type'];
    $quantity = $_POST['quantity'];

    // Validate the input
    if (empty($product_id) || empty($transaction_type) || empty($quantity) || $quantity <= 0) {
        echo "Invalid input. Please go back and try again.";
        exit;
    }

    // Insert the data into the product_transactions table
    $stmt = $conn->prepare("INSERT INTO product_transactions (product_id, transaction_type, quantity) VALUES (?, ?, ?)");
    $stmt->bind_param("isi", $product_id, $transaction_type, $quantity);

    if ($stmt->execute()) {
        echo "Transaction added successfully.";
        header("Location: admin_dashboard.php");  // Redirect to the admin dashboard
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
