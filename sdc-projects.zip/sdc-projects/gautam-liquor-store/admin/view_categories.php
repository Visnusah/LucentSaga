<?php
    session_start();
    if(!isset($_SESSION['admin_id'])){
        header("Location: index.php");
        exit;
    }
    include_once '../db.php';
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="admin-style.css">
    </head>
    <body>
        <?php include './components/navbar.php' ?>
        <div class="container-fluid" style="margin-top: 3.5rem;">
            <div class="row">
                <?php include './components/sidebar.php' ?>
                <main role="main" class="col-md-9 col-lg-9 px-4">
                    <div class="content mt-5">
                        <h3>Manage Categories</h3>
                        <p><a class="btn btn-primary" href="add_category.php">Add New Category</a></p>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Category ID</th>
                                    <th scope="col">Category Name</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $sql = "SELECT * FROM categories";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while($row = $result->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td>" . $row['id'] . "</td>";
                                            echo "<td>" . $row['name'] . "</td>";
                                            echo "<td><a href='edit_category.php?id=".$row['id']."'>Edit</a> | <a href='delete_category.php?id=".$row['id']."'>Delete</a></td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='5'>No categories found</td></tr>";
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </main>
            </div>
        </div>
        
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </body>
</html>
