<?php
session_start();
if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit;
}
include_once '../db.php';

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql = "UPDATE orders SET status='completed' WHERE id='$id'";
    
    if($conn->query($sql) === TRUE){
        header("Location: view_orders.php");
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>
