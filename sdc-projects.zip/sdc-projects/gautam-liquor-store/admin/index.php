<?php
    session_start();
    if(isset($_SESSION['admin_id'])){
        header("Location: admin_dashboard.php");
        exit;
    }
    include_once '../db.php';
    
    if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE username='$username' AND password='$password' AND role='admin'";
        $result = $conn->query($sql);

        if($result->num_rows > 0){
            $row = $result->fetch_assoc();
            $_SESSION['admin_id'] = $row['id'];
            header("Location: admin_dashboard.php");
            exit;
        } else {
            $error = "Invalid username or password!";
        }
    }

    
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Login</title>
         <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body>
    <div class="d-lg-flex half">
    <div class="bg order-1 order-md-2" style="background-image: url('../images/barrel.jpg');"></div>
    <div class="contents order-2 order-md-1">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7">
            <h3>Login as <strong>Admin</strong></h3>
            <p class="mb-4">Gautam Liquor Store - #1 Online Liquor Store in Nepal.</p>
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                            <div class="form-group">
                                <label for="username">Username:</label><br>
                                <input type="text" name="username" id="username" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label><br>
                                <input type="text" name="password" id="password" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="submit" name="login" class="btn custom-btn" value="Login">
                            </div>
                        </form>
                        </div>
        </div>
      </div>
    </div>

    
  </div>
    </body>
</html>
