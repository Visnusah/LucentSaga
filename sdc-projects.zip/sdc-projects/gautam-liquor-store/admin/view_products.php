<?php
    session_start();
    if(!isset($_SESSION['admin_id'])){
        header("Location: index.php");
        exit;
    }
    include_once '../db.php';
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="admin-style.css">
    </head>
    <body>
        <?php include './components/navbar.php' ?>
        <div class="container-fluid" style="margin-top: 3.5rem;">
            <div class="row">
                <?php include './components/sidebar.php' ?>
                <main role="main" class="col-md-9 col-lg-10 px-4">
                    <div class="content mt-5">
                        <h3>Manage Products</h3>
                        <p><a class="btn btn-primary" href="add_product.php">Add New Product</a></p>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>SKU</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $sql = "SELECT * FROM products";
                                    $result = $conn->query($sql);

                                    if($result->num_rows > 0){
                                        while($row = $result->fetch_assoc()){
                                            echo "<tr>";
                                            echo "<td>".$row['sku']."</td>";
                                            echo "<td>".$row['name']."</td>";
                                            echo "<td>".$row['description']."</td>";
                                            echo "<td>".$row['price']."</td>";
                                            echo "<td>" ?> 
                                            <button onclick="updateQuantity(<?php echo $row['id']; ?>, 'increment')" class="btn btn-success">+</button>
                                            <?php echo $row['quantity'] ?>
                                            <button onclick="updateQuantity(<?php echo $row['id']; ?>, 'decrement')" class="btn btn-danger">-</button>
                                            <?php "</td>";
                                            echo "<td><a href='edit_product.php?id=".$row['id']."'>Edit</a> | <a href='delete_product.php?id=".$row['id']."'>Delete</a></td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='5'>No products found!</td></tr>";
                                    }
                                ?>
                            </tbody>
                    </table>
                    </div>
                </main>
            </div>
        </div>
        
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
        function updateQuantity(productId, action) {
            $.ajax({
                url: 'update_quantity.php',
                type: 'POST',
                data: {id: productId, action: action},
                success: function(response) {
                    location.reload(); // Reload the page to see the updated quantity
                },
                error: function() {
                    alert('Error updating quantity');
                }
            });
        }
        </script>
    </body>
</html>
