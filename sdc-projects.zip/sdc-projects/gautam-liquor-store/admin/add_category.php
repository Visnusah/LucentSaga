<?php
    session_start();
    if(!isset($_SESSION['admin_id'])){
        header("Location: admin_login.php");
        exit;
    }
    include_once '../db.php';
?>

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="admin-style.css">
    </head>
    <body>
        <?php include './components/navbar.php' ?>
        <div class="container-fluid" style="margin-top: 3.5rem;">
            <div class="row">
                <?php include './components/sidebar.php' ?>
                <main role="main" class="col-md-9 col-lg-9 px-4">
                    <div class="content mt-5">
                            <?php
                                if(isset($_POST['categoryName']) && !empty($_POST['categoryName'])){
                                    $categoryName = $_POST['categoryName'];
                            
                                    $sql = "SELECT * FROM categories WHERE name='$categoryName'";
                                    $result = $conn->query($sql);
                            
                                    if ($result->num_rows > 0) {
                                        echo "<div class='container mt-4 alert alert-danger'>Category '$categoryName' already exists!</div>";
                                    } else {
                                        $insertSql = "INSERT INTO categories (name) VALUES ('$categoryName')";
                                        if ($conn->query($insertSql) === TRUE) {
                                            echo "<div class='container mt-5 alert alert-success'>Category '$categoryName' added successfully!</div>";
                                        } else {
                                            echo "<div class='container mt-5 alert alert-danger'>Error adding category: " . $conn->error . "</div>";
                                        }
                                    }
                                }
                            ?>

                            <h2>Add New Category</h2>
                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <div class="form-group">
                                    <label for="categoryName">Category Name</label>
                                    <input type="text" class="form-control" name="categoryName" id="categoryName" placeholder="Enter category name" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Add Category</button>
                            </form>

                           
                    </div>
                </main>
            </div>
        </div>
</body>
</html>
