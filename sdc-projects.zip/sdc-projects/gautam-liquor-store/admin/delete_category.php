<?php
    session_start();
    if(!isset($_SESSION['admin_id'])){
        header("Location: admin_login.php");
        exit;
    }
    include_once '../db.php';

    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $sql = "DELETE FROM categories WHERE id='$id'";
        
        if($conn->query($sql) === TRUE){
            header("Location: admin_dashboard.php");
            exit;
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    }
?>
