<?php
session_start();
include '../db.php';  // Include your database connection setup here

// Check if user is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

// Fetch products for the dropdown
$sql_products = "SELECT id, name FROM products";
$result_products = $conn->query($sql_products);
$products = [];
if($result_products->num_rows > 0) {
    while($row = $result_products->fetch_assoc()) {
        $products[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Transaction</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include './components/navbar.php'; ?>
    <div class="container" style="margin-top: 3.5rem;">
        <h2>Add Product Transaction</h2>
        <form action="process_transaction.php" method="POST">
            <div class="form-group">
                <label for="product">Product</label>
                <select class="form-control" id="product" name="product_id" required>
                    <option value="">Select a product</option>
                    <?php foreach($products as $product): ?>
                        <option value="<?php echo $product['id']; ?>"><?php echo $product['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="transaction_type">Transaction Type</label>
                <select class="form-control" id="transaction_type" name="transaction_type" required>
                    <option value="buy">Buy</option>
                    <option value="sell">Sell</option>
                </select>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity</label>
                <input type="number" class="form-control" id="quantity" name="quantity" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Transaction</button>
        </form>
    </div>
</body>
</html>
