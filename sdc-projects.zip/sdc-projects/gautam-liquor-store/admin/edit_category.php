<?php
session_start();
if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit;
}
include_once '../db.php';

if(isset($_POST['update_category'])){
    $id = $_POST['id'];
    $name = $_POST['name'];

    $sql = "UPDATE categories SET name='$name' WHERE id='$id'";
    
    if($conn->query($sql) === TRUE){
        header("Location: admin_dashboard.php");
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql = "SELECT * FROM categories WHERE id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="admin-style.css">
    </head>
    <body>
        <?php include './components/navbar.php' ?>
        <div class="container-fluid" style="margin-top: 3.5rem;">
            <div class="row">
                <?php include './components/sidebar.php' ?>
                <main role="main" class="col-md-9 col-lg-9 px-4">
                    <div class="content mt-5">
                        <h2>Edit Category</h2>
                        <form method="post">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <div class="form-group">
                                <label for="categoryName">Category Name</label>
                                <input type="text" class="form-control" name="categoryName" id="categoryName" value="<?php echo $row['name']; ?>" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Update Category</button>
                        </form>
                    </div>
                </main>
            </div>
        </div>
</body>
</html>
