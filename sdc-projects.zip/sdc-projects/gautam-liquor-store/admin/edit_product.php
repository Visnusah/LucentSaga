<?php
    session_start();
    if(!isset($_SESSION['admin_id'])){
        header("Location: admin_login.php");
        exit;
    }
    include_once '../db.php';

    if(isset($_GET['id'])){
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        // Fetch product details
        $productResult = $conn->query("SELECT * FROM products WHERE id = $id");
        $product = $productResult->fetch_assoc();

        // Fetch categories
        $categoryResult = $conn->query("SELECT * FROM categories");
        $categories = [];
        while ($row = $categoryResult->fetch_assoc()) {
            $categories[$row['id']] = $row['name'];
        }

        if (!$product) {
            echo "No product found!";
            exit;
        }
    }

    if(isset($_POST['update_product'])){
        $id = $_POST['id'];
        $sku = $_POST['sku'];
        $description = $_POST['description'];
        $name = $_POST['name'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        $category_id = $_POST['category_id'];

        if(isset($_FILE['image']) && !empty($_FILE['image'])){
            $targetDir = "uploads/";
            $fileName = $_FILES['image']['name'];
            $tmp = explode('.', $fileName);
            $imageFileType = strtolower(end($tmp));
            $uploadOk = 1;
            
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check !== false) {
                $uploadOk = 1;
            } else {
                echo "<div class='container mt-5 alert alert-danger'>File is not an image.</div>";
                $uploadOk = 0;
            }
            
            if (file_exists($targetFile)) {
                echo "<div class='container mt-5 alert alert-danger'>Sorry, file already exists.</div>";
                $uploadOk = 0;
            }
            
            if ($_FILES["image"]["size"] > 500000) {
                echo "<div class='container mt-5 alert alert-danger'>Sorry, your file is too large.</div>";
                $uploadOk = 0;
            }
            
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
                echo "<div class='container mt-5 alert alert-danger'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
                $uploadOk = 0;
            }
            
            if ($uploadOk == 0) {
                echo "<div class='container mt-5 alert alert-danger'>Sorry, your file was not uploaded.</div>";

            } else {
                $newFileName = uniqid('img_', true) . '.' . $imageFileType;
                $targetFile = $targetDir . $newFileName;

                if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                    echo "<div class='container mt-5 alert alert-success'>The file ". htmlspecialchars( basename( $_FILES["image"]["name"])). " has been uploaded.</div>";
                } else {
                    echo "<div class='container mt-5 alert alert-danger'>Sorry, there was an error uploading your file.</div>";
                }
            }
        }

        $conn = new mysqli('localhost', 'root', '', 'gautam-liquor-store');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        echo $fileNameSet;
        $updateSql = "UPDATE products SET sku='$sku', name='$name', description='$description', price='$price', quantity='$quantity', category_id='$category_id', product_image='$fileNameSet' WHERE id=$id";

        if ($conn->query($updateSql) === TRUE) {
            echo "<div class='container mt-5 alert alert-success'>Product added successfully!</div>";
            header("location: view_products.php");
        } else {
            
            echo "<div class='container mt-5 alert alert-danger'>Error adding product: " . $conn->error."</div>";
        }
        $conn->close();
    }

?>

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="admin-style.css">
    </head>
    <body>
        <?php include './components/navbar.php' ?>
        <div class="container-fluid" style="margin-top: 3.5rem;">
            <div class="row">
                <?php include './components/sidebar.php' ?>
                <main role="main" class="col-md-9 col-lg-9 px-4">
                    <div class="content mt-5">
                    <h2>Edit Product</h2>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                        <div class="form-group">
                            <label for="sku">SKU:</label>
                            <input type="text" class="form-control" name="sku" id="sku" value="<?php echo $product['sku']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" class="form-control" name="name" id="name" value="<?php echo $product['name']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="productDescription">Product Description</label>
                            <textarea class="form-control" id="productDescription" name="description" rows="3" required><?php echo $product['description']; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="price">Price:</label>
                            <input type="number" class="form-control" name="price" id="price" value="<?php echo $product['price']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="quantity">Quantity:</label>
                            <input type="number" class="form-control" name="quantity" id="quantity" value="<?php echo $product['quantity']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="category">Category:</label>
                            <select class="form-control" id="category" name="category_id">
                                <?php foreach ($categories as $categoryId => $categoryName): ?>
                                    <option value="<?php echo $categoryId; ?>" <?php echo ($categoryId == $product['category_id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($categoryName); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="image">Product Image:</label>
                            <input type="file" class="form-control" name="image" id="image">
                            <?php if ($product['product_image']): ?>
                                <img src="uploads/<?php echo $product['product_image']; ?>" alt="" style="width: 100px; height: auto;">
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-primary" name="update_product">Update Product</button>
                    </form>  
                    </div>
                </main>
            </div>
        </div>
    </body>
</html>