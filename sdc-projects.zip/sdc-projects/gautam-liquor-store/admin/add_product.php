<?php
    session_start();
    if(!isset($_SESSION['admin_id'])){
        header("Location: admin_login.php");
        exit;
    }
    include_once '../db.php';
?>

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="admin-style.css">
    </head>
    <body>
        <?php include './components/navbar.php' ?>
        <div class="container-fluid" style="margin-top: 3.5rem;">
            <div class="row">
                <?php include './components/sidebar.php' ?>
                <main role="main" class="col-md-9 col-lg-9 px-4">
                    <div class="content mt-5">
                                <h2>Add New Product</h2>
                                <form method="post" action="add_product.php" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="productName">Product Name</label>
                                        <input type="text" class="form-control" id="productName" name="productName" placeholder="Enter product name" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="productDescription">Product Description</label>
                                        <textarea class="form-control" id="productDescription" name="productDescription" rows="3" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="productPrice">Price</label>
                                        <input type="number" class="form-control" id="productPrice" name="productPrice" placeholder="Enter product price" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="productQuantity">Quantity</label>
                                        <input type="number" class="form-control" id="productQuantity" name="productQuantity" placeholder="Enter product quantity" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="productCategory">Category</label>
                                        <select class="form-control" id="productCategory" name="productCategory">
                                            <?php
                                                $sql = "SELECT * FROM categories";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while($row = $result->fetch_assoc()) {
                                                        echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                                                    }
                                                }
                                                $conn->close();
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="productSKU">SKU</label>
                                        <input type="text" class="form-control" id="productSKU" name="productSKU" placeholder="Enter product SKU" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="productImage">Product Image</label>
                                        <input type="file" class="form-control-file" id="productImage" name="productImage" accept="image/*" required>
                                    </div>
                              
                                    <button type="submit" class="btn btn-primary" name="submit">Add Product</button>
                                </form>
                            </div>
                            
                            
                            <?php
                            if(isset($_POST['submit'])) {

                                $productName = $_POST['productName'];
                                $productDescription = $_POST['productDescription'];
                                $productPrice = $_POST['productPrice'];
                                $productQuantity = $_POST['productQuantity'];
                                $productCategory = $_POST['productCategory'];
                                $productSKU = $_POST['productSKU'];
                                
                                $targetDir = "uploads/";
                                $fileName = $_FILES['productImage']['name'];
                                $tmp = explode('.', $fileName);
                                $imageFileType = strtolower(end($tmp));
                                $uploadOk = 1;
                                
                                $check = getimagesize($_FILES["productImage"]["tmp_name"]);
                                if($check !== false) {
                                    $uploadOk = 1;
                                } else {
                                    echo "<div class='container mt-5 alert alert-danger'>File is not an image.</div>";
                                    $uploadOk = 0;
                                }
                                $targetFile = '';
                                if (file_exists($targetFile)) {
                                    echo "<div class='container mt-5 alert alert-danger'>Sorry, file already exists.</div>";
                                    $uploadOk = 0;
                                }
                                
                                if ($_FILES["productImage"]["size"] > 500000) {
                                    echo "<div class='container mt-5 alert alert-danger'>Sorry, your file is too large.</div>";
                                    $uploadOk = 0;
                                }
                                
                                if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                                && $imageFileType != "gif" ) {
                                    echo "<div class='container mt-5 alert alert-danger'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
                                    $uploadOk = 0;
                                }
                                
                                if ($uploadOk == 0) {
                                    echo "<div class='container mt-5 alert alert-danger'>Sorry, your file was not uploaded.</div>";

                                } else {
                                    $newFileName = uniqid('img_', true) . '.' . $imageFileType;
                                    $targetFile = $targetDir . $newFileName;

                                    if (move_uploaded_file($_FILES["productImage"]["tmp_name"], $targetFile)) {
                                        
                                        $conn = new mysqli('localhost', 'root', '', 'gautam-liquor-store');
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }
                                        
                                        $sql = "INSERT INTO products (name, description, price, quantity, category_id, sku, product_image) 
                                                    VALUES ('$productName', '$productDescription', '$productPrice', '$productQuantity', '$productCategory', '$productSKU', '$newFileName')";

                                        if ($conn->query($sql) === TRUE) {
                                            echo "<div class='container mt-5 alert alert-success'>Product added successfully!</div>";
                                        } else {
                                            
                                            echo "<div class='container mt-5 alert alert-danger'>Error adding product: " . $conn->error."</div>";
                                        }
                                        $conn->close();
                                    } else {
                                        echo "<div class='container mt-5 alert alert-danger'>Sorry, there was an error uploading your file.</div>";
                                    }
                                }
                            }
                            ?>
                        </form>
                    </div>
                </main>
            </div>
        </div>
    </body>
</html>
