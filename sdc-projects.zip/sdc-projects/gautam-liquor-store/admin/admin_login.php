<?php
    session_start();
    if(isset($_SESSION['admin_id'])){
        header("Location: admin_dashboard.php");
        exit;
    }
    include_once '../db.php';
    
    if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE username='$username' AND password='$password' AND role='admin'";
        $result = $conn->query($sql);

        if($result->num_rows > 0){
            $row = $result->fetch_assoc();
            $_SESSION['admin_id'] = $row['id'];
            header("Location: admin_dashboard.php");
            exit;
        } else {
            $error = "Invalid username or password!";
        }
    }
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Login</title>
    </head>
    <body>
        <h2>Admin Login</h2>
        <?php if(isset($error)) { echo "<p>$error</p>"; } ?>
        <form method="post">
            <label>Username:</label><br>
            <input type="text" name="username" required><br>
            <label>Password:</label><br>
            <input type="password" name="password" required><br><br>
            <input type="submit" name="login" value="Login">
        </form>
    </body>
</html>
