<?php
include '../db.php';

if (isset($_POST['id']) && isset($_POST['action'])) {
    $productId = intval($_POST['id']);
    $action = $_POST['action'];

    $changeAmount = ($action == 'increment') ? 1 : -1;

    $query = "UPDATE products SET quantity = quantity + ($changeAmount) WHERE id = $productId";
    $result = $conn->query($query);

    if ($result) {
        echo "Quantity updated";
    } else {
        echo "Error updating quantity";
    }
} else {
    echo "No data provided";
}

$conn->close();
?>
