<?php
// PayPal Configuration
if (!defined('PAYPAL_EMAIL')) { define('PAYPAL_EMAIL', 'sb-8iw43m30935712@business.example.com'); }
if (!defined('RETURN_URL')) { define('RETURN_URL', 'http://localhost/sdc-projects/gautam-liquor-store/client/return.php'); }
if (!defined('CANCEL_URL')) { define('CANCEL_URL', 'http://localhost/sdc-projects/gautam-liquor-store/client/cancel.php'); }
if (!defined('NOTIFY_URL')) { define('NOTIFY_URL', 'http://localhost/sdc-projects/gautam-liquor-store/client/notify.php'); }
if (!defined('CURRENCY')) { define('CURRENCY', 'USD'); }
if (!defined('SANDBOX')) { define('SANDBOX', TRUE); } // TRUE or FALSE
if (!defined('LOCAL_CERTIFICATE')) { define('LOCAL_CERTIFICATE', FALSE); } // TRUE or FALSE

if (SANDBOX === TRUE) {
    $paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
} else {
    $paypal_url = "https://www.paypal.com/cgi-bin/webscr";
}

// PayPal IPN Data Validate URL
if (!defined('PAYPAL_URL')) { define('PAYPAL_URL', $paypal_url); }

$servername = "localhost";
$username = "root";
$password = "";
$database = "gautam-liquor-store";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
